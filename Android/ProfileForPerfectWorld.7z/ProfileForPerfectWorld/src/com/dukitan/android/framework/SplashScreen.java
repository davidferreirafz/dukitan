package com.dukitan.android.framework;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ProgressBar;

import com.dukitan.android.profileperfectworld.ProfilePerfectWorldActivity;
import com.dukitan.android.profileperfectworld.R;

public class SplashScreen extends Activity implements Runnable
{

    ProgressBar progressBar;
    int         contagem = 0;
    Handler     handler;
    Thread      thread;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

        progressBar = (ProgressBar) findViewById(R.id.splashProgressBar);

        handler = new Handler() {

            @Override
            public void handleMessage(Message msg)
            {
                contagem++;
                progressBar.setProgress(contagem);
            }
        };

        thread = new Thread(this);

        thread.start();
    }

    public void run()
    {
        while (contagem < 100) {
            try {
                handler.sendMessage(handler.obtainMessage());
                Thread.sleep(10);
            } catch (Throwable t) {
            }
        }

        startActivity(new Intent(this, ProfilePerfectWorldActivity.class));

        thread.interrupt();
        finish();
    }

}
