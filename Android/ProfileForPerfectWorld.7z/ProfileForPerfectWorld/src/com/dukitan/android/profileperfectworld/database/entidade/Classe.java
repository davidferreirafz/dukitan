package com.dukitan.android.profileperfectworld.database.entidade;

public class Classe extends Atributo
{
    private int idClasse;

    public int getIdClasse()
    {
        return idClasse;
    }

    public void setIdClasse(int idClasse)
    {
        this.idClasse = idClasse;
    }

}
