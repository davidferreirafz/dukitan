package com.dukitan.android.profileperfectworld;

import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

import com.dukitan.android.framework.Application;
import com.dukitan.android.profileperfectworld.database.DAO;
import com.dukitan.android.profileperfectworld.database.entidade.Atributo;

public class ProfilePerfectWorldActivity extends Application
{
    /** Called when the activity is first created. */

    DAO             dao;
    Spinner         spinnerRaces;
    Spinner         spinnerClasses;
    Spinner         spinnerBuild;
    EditText        editVit;
    EditText        editStr;
    EditText        editMag;
    EditText        editDex;
    EditText        editLevel;

    private int     idRaca;
    private int     idClasse;
    private int     idPerfil;
    private TabHost tabs;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Configuration c = getApplicationContext().getResources().getConfiguration();

        DAO.setContext(getApplicationContext());
        DAO.setLanguage(c.locale.getISO3Language());

        dao = DAO.getInstance();

        tabs = (TabHost) this.findViewById(R.id.my_tabhost);
        tabs.setup();

        TabSpec tspec1 = tabs.newTabSpec(getResources().getString(R.string.Char));
        tspec1.setIndicator(getResources().getString(R.string.Char));
        tspec1.setContent(R.id.tab1);
        tabs.addTab(tspec1);
        TabSpec tspec2 = tabs.newTabSpec(getResources().getString(R.string.Attributes));
        tspec2.setIndicator(getResources().getString(R.string.Attributes));
        tspec2.setContent(R.id.tab2);
        tabs.addTab(tspec2);

        spinnerRaces = (Spinner) this.findViewById(R.id.spinnerRaces);
        spinnerClasses = (Spinner) this.findViewById(R.id.spinnerClasses);
        spinnerBuild = (Spinner) this.findViewById(R.id.spinnerBuild);

        editVit = (EditText) this.findViewById(R.id.editVit);
        editStr = (EditText) this.findViewById(R.id.editStr);
        editMag = (EditText) this.findViewById(R.id.editMag);
        editDex = (EditText) this.findViewById(R.id.editDex);
        editLevel = (EditText) this.findViewById(R.id.editLevel);

        final Button button = (Button) findViewById(R.id.buttonCalculate);

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                Atributo atributo = Calcular.executar(idRaca, idClasse, idPerfil, Integer.parseInt(editLevel.getText().toString()));

                editMag.setText(String.valueOf(atributo.getMag()));
                editStr.setText(String.valueOf(atributo.getStr()));
                editVit.setText(String.valueOf(atributo.getVit()));
                editDex.setText(String.valueOf(atributo.getDex()));

                tabs.setCurrentTab(1);
            }
        });

        OnItemSelectedListener mMessageClickedHandler = new OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View v, int position, long id)
            {
                idRaca = (int) id;
                popularClasses(idRaca);

            }

            public void onNothingSelected(AdapterView<?> parent)
            {
                return;
            }
        };

        spinnerRaces.setOnItemSelectedListener(mMessageClickedHandler);

        OnItemSelectedListener mMessageClickedHandler2 = new OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View v, int position, long id)
            {
                idClasse = (int) id;
                popularBuilds(idClasse);
            }

            public void onNothingSelected(AdapterView<?> parent)
            {
                return;
            }
        };

        spinnerClasses.setOnItemSelectedListener(mMessageClickedHandler2);

        OnItemSelectedListener mMessageClickedHandler3 = new OnItemSelectedListener() {

            public void onItemSelected(AdapterView<?> parent, View v, int position, long id)
            {
                idPerfil = (int) id;
            }

            public void onNothingSelected(AdapterView<?> parent)
            {
                return;
            }
        };

        spinnerBuild.setOnItemSelectedListener(mMessageClickedHandler3);

        popularRaces();
    }

    private void popularRaces()
    {
        Cursor cursorRaces = dao.queryRacesCursor();
        startManagingCursor(cursorRaces);

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, android.R.layout.simple_spinner_item, cursorRaces, new String[] { "raca" },
                new int[] { android.R.id.text1 });

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRaces.setAdapter(adapter);
    }

    private void popularClasses(int id)
    {
        Cursor cursorClasses = null;
        if (id > 0) {
            cursorClasses = dao.queryClassesCursor(id);
            startManagingCursor(cursorClasses);

            SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, android.R.layout.simple_spinner_item, cursorClasses,
                    new String[] { "classe" }, new int[] { android.R.id.text1 });

            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerClasses.setAdapter(adapter);
        }

        ativarSpinner(spinnerClasses, id, cursorClasses);
    }

    private void popularBuilds(int id)
    {
        Cursor cursorBuilds = null;
        if (id > 0) {
            cursorBuilds = dao.queryBuildCursor(id);
            startManagingCursor(cursorBuilds);

            SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, android.R.layout.simple_spinner_item, cursorBuilds,
                    new String[] { "perfil" }, new int[] { android.R.id.text1 });

            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerBuild.setAdapter(adapter);
        }

        ativarSpinner(spinnerBuild, id, cursorBuilds);
    }

    private void ativarSpinner(Spinner spinner, int id, Cursor cursor)
    {
        if ((id <= 0) || (cursor == null) || (cursor.getCount() <= 0)) {
            spinner.setClickable(false);
            spinner.setEnabled(false);
        } else {
            spinner.setClickable(true);
            spinner.setEnabled(true);
        }
    }

}