package com.dukitan.android.profileperfectworld.database.entidade;

public class Raca
{
    private int idRaca;
    private String raca;
    
    public int getIdRaca()
    {
        return idRaca;
    }
    public void setIdRaca(int idRaca)
    {
        this.idRaca = idRaca;
    }
    public String getRaca()
    {
        return raca;
    }
    public void setRaca(String raca)
    {
        this.raca = raca;
    }
    
    
}
