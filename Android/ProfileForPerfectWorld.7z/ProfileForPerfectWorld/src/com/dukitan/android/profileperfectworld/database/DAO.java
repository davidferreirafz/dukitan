package com.dukitan.android.profileperfectworld.database;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.dukitan.android.profileperfectworld.database.entidade.Classe;
import com.dukitan.android.profileperfectworld.database.entidade.Perfil;

public class DAO
{
    private SQLiteDatabase db       = null;
    private DBHelper       dbHelper = null;
    private static DAO     instance = null;
    private static Context context  = null;
    private static String  language;

    private DAO()
    {
        dbHelper = new DBHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    static public DAO getInstance()
    {
        if (instance == null) {
            instance = new DAO();
        }

        return instance;
    }

    public static void setContext(Context context)
    {
        DAO.context = context;
    }

    public static void setLanguage(String language)
    {
        if ("por".equals(language)){
            DAO.language = "pt";    
        } else {
            DAO.language = "en";
        }
        
    }

    public Cursor queryRacesCursor()
    {
        this.db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT idRaca as _id, raca_"+language+" as raca FROM Raca Order by raca", null);

        return cursor;
    }

    public Cursor queryClassesCursor(int idRace)
    {
        this.db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT idClasse as _id, classe_"+language+" as classe FROM Classe WHERE idRaca='" + idRace + "' Order by classe", null);

        return cursor;
    }

    public Cursor queryBuildCursor(int idClasse)
    {
        this.db = dbHelper.getWritableDatabase();

        Cursor cursor = db
                .rawQuery("SELECT idPerfil as _id, perfil_"+language+" as perfil FROM Perfil WHERE idClasse='" + idClasse + "' Order by perfil", null);

        return cursor;
    }

    public Perfil getPerfil(int id)
    {
        Perfil to = new Perfil();

        Cursor cursor = db.rawQuery("SELECT idPerfil, mag, dex, str, vit FROM Perfil WHERE idPerfil='" + id + "'", null);

        if (cursor.moveToFirst()) {
            to.setIdPerfil(cursor.getInt(0));
            to.setMag(cursor.getInt(1));
            to.setDex(cursor.getInt(2));
            to.setStr(cursor.getInt(3));
            to.setVit(cursor.getInt(4));
            cursor.close();
        }

        return to;
    }

    public Classe getClasse(int id)
    {
        Classe to = new Classe();

        Cursor cursor = db.rawQuery("SELECT idClasse, mag, dex, str, vit FROM Classe WHERE idClasse='" + id + "'", null);

        if (cursor.moveToFirst()) {
            to.setIdClasse(cursor.getInt(0));
            to.setMag(cursor.getInt(1));
            to.setDex(cursor.getInt(2));
            to.setStr(cursor.getInt(3));
            to.setVit(cursor.getInt(4));
            cursor.close();
        }

        return to;
    }

}
