package com.dukitan.android.profileperfectworld.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper
{

    private static final String DATABASE_NAME    = "profileperfectworld.db";
    public static final int     DATABASE_VERSION = 1;

    public DBHelper(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE Raca (idRaca INTEGER PRIMARY KEY, raca_pt TEXT NOT NULL , raca_en TEXT NOT NULL )");
        db.execSQL("INSERT  INTO Raca (idRaca,raca_pt,raca_en) VALUES ('1','Humano','Humans')");
        db.execSQL("INSERT  INTO Raca (idRaca,raca_pt,raca_en) VALUES ('2','Alado','Winged Elves')");
        db.execSQL("INSERT  INTO Raca (idRaca,raca_pt,raca_en) VALUES ('3','Selvagem','Untamed')");

        db.execSQL("CREATE TABLE Classe (idClasse INTEGER PRIMARY KEY, idRaca INTEGER NOT NULL, classe_pt TEXT NOT NULL, classe_en TEXT NOT NULL, str INTEGER NOT NULL, dex INTEGER NOT NULL, mag INTEGER NOT NULL,vit INTEGER NOT NULL)");
        db.execSQL("INSERT  INTO Classe (idClasse,idRaca,classe_pt,classe_en,str,dex,mag,vit) values ('1','1','Mago','Wizard','5','5','5','5')");
        db.execSQL("INSERT  INTO Classe (idClasse,idRaca,classe_pt,classe_en,str,dex,mag,vit) values ('2','1','Guerreiro','Blademaster','5','5','5','5')");
        db.execSQL("INSERT  INTO Classe (idClasse,idRaca,classe_pt,classe_en,str,dex,mag,vit) values ('3','2','Arqueiro','Archer','5','5','5','5')");
        db.execSQL("INSERT  INTO Classe (idClasse,idRaca,classe_pt,classe_en,str,dex,mag,vit) values ('4','2','Sacerdote','Cleric','5','5','5','5')");
        db.execSQL("INSERT  INTO Classe (idClasse,idRaca,classe_pt,classe_en,str,dex,mag,vit) values ('5','3','Barbaro','Barbarian','5','5', '5','5')");
        db.execSQL("INSERT  INTO Classe (idClasse,idRaca,classe_pt,classe_en,str,dex,mag,vit) values ('6','3','Feiticeira','Venomancer','5','5','5','5')");

        db.execSQL("CREATE TABLE Perfil (idPerfil INTEGER PRIMARY KEY, idClasse INTEGER NOT NULL, perfil_pt TEXT NOT NULL, perfil_en TEXT NOT NULL, mag INTEGER NOT NULL, str INTEGER NOT NULL, vit INTEGER NOT NULL,dex INTEGER NOT NULL)");
        // MAGO - WIZARD
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('10','1','Híbrido','Hybrid','8','1','1','0')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('11','1','Pure','Pure','9','1','0','0')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('12','1','Tanker','Tanker','6','3','1','0')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('13','1','Armadura Leve','Light Armor','3','1','0','1')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('14','1','Equilibrado','Balanced','2','1','1','1')");
        // GUERREIRO - BLADEMASTER
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('20','2','Machados, Martelos','Hammer','0','6','3','1')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('21','2','Espadas, Laminas','Sword','0','4','3','3')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('22','2','Lancas','Pole','0','5','3','2')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('23','2','Garras','Claws','0','3','3','4')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('24','2','Híbrido, Machados e Espadas','Hybrid','0','6','1','3')");
        // ARQUEIRO - ARCHER
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('30','3','Armadura Leve','Light Armor','6','2','0','2')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('31','3','Equilibrado','Balanced','6','1','3','0')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('32','3','Full Dex/Accuracy','Full Dex/Accuracy','0','1','0','4')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('33','3','Híbrido','Hybrid','0','1','1','8')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('34','3','Híbrido/Vitalidade','Vitality/Hybrid','0','2','1','7')");
        // SACER - CLERIC
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('40','4','Armadura Leve','Light Armor','3','1','0','1')");       
        // BARBARO - BARBARIAN
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('50','5','Armadura Leve','Light Armor','0','3','1','1')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('51','5','Híbrido','Hybrid','0','5','2','3')");               
        // FEITICEIRA - VENOMANCER
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('60','6','Pure','Pure','9','1','0','0')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('61','6','Armadura Leve','Light Armor','3','1','0','1')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('62','6','Armadura Pesada/Arcana','Heavy and Arcane Armor','6','5','0','1')");
        db.execSQL("INSERT  INTO Perfil (idPerfil,idClasse,perfil_pt,perfil_en,mag,str,vit,dex) values('63','6','Vitality','Vitality','6','1','3','0')");        
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        //if (newVersion >= oldVersion) {
            db.execSQL("DROP TABLE IF EXIST Raca");
            db.execSQL("DROP TABLE IF EXIST Classe");
            db.execSQL("DROP TABLE IF EXIST Perfil");
            onCreate(db);
        //}
    }

}
