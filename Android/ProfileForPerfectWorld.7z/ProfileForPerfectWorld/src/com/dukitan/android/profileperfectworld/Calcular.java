package com.dukitan.android.profileperfectworld;

import com.dukitan.android.profileperfectworld.database.DAO;
import com.dukitan.android.profileperfectworld.database.entidade.Atributo;
import com.dukitan.android.profileperfectworld.database.entidade.Classe;
import com.dukitan.android.profileperfectworld.database.entidade.Perfil;

public class Calcular
{

    public static Atributo executar(int idRaca, int idClasse, int idPerfil, int nivel)
    {
        // Pontos por Nivel
        int pontoNivel = 5;

        DAO dao = DAO.getInstance();

        Perfil perfil = dao.getPerfil(idPerfil);

        Classe classe = dao.getClasse(idClasse);

        int ratioPerfil = perfil.getMag() + perfil.getStr() + perfil.getVit() + perfil.getDex();
        // Total de Pontos do Nivel
        int totalPontos = (nivel - 1) * pontoNivel;

        Atributo atributo = new Atributo();

        atributo.setMag(((totalPontos / ratioPerfil) * perfil.getMag()) + classe.getMag());
        atributo.setStr(((totalPontos / ratioPerfil) * perfil.getStr()) + classe.getStr());
        atributo.setVit(((totalPontos / ratioPerfil) * perfil.getVit()) + classe.getVit());
        atributo.setDex(((totalPontos / ratioPerfil) * perfil.getDex()) + classe.getDex());

        return atributo;
    }

}
