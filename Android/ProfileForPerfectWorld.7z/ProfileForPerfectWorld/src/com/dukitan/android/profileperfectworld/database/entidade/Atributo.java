package com.dukitan.android.profileperfectworld.database.entidade;

public class Atributo
{
    private int mag;
    private int str;
    private int vit;
    private int dex;

    public int getMag()
    {
        return mag;
    }

    public void setMag(int mag)
    {
        this.mag = mag;
    }

    public int getStr()
    {
        return str;
    }

    public void setStr(int str)
    {
        this.str = str;
    }

    public int getVit()
    {
        return vit;
    }

    public void setVit(int vit)
    {
        this.vit = vit;
    }

    public int getDex()
    {
        return dex;
    }

    public void setDex(int dex)
    {
        this.dex = dex;
    }
}
