package com.dukitan.android.profileperfectworld.database.entidade;

public class Perfil extends Atributo
{
    private int idPerfil;

    public int getIdPerfil()
    {
        return idPerfil;
    }

    public void setIdPerfil(int idPerfil)
    {
        this.idPerfil = idPerfil;
    }
}
