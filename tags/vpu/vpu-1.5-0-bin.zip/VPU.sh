#!/bin/sh
export CLASSPATH=.:$CLASSPATH:$JAVA_HOME 
java -jar vpu-1.5-bin.jar
